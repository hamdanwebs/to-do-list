document.getElementById('submit-btn').addEventListener('click', function() {
    const inputField = document.getElementById('input-field');
    const newTask = inputField.value.trim();

    if (newTask !== "") {
        const listItem = document.createElement('li');
        listItem.innerHTML = `${newTask} <button class="delete-btn">Delete</button>`;
        
        // Add delete functionality
        listItem.querySelector('.delete-btn').addEventListener('click', function() {
            listItem.remove();
        });

        document.getElementById('todo-list').appendChild(listItem);
        inputField.value = ""; // Clear the input field
    } else {
        alert("Please enter a task!");
    }
});
